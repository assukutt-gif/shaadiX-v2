import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:5000/api";
const categories = ["All", "Catering", "Cooks & Chefs", "Staff", "Entertainment", "Decoration", "Photography", "Beauty", "Venue"];

export default function App() {
  const [services, setServices] = useState([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [chosen, setChosen] = useState(null);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ customerName: "", phone: "", eventType: "Marriage", eventDate: "", location: "", quantity: "1", hours: "1", notes: "" });

  async function loadServices() {
    try {
      const r = await fetch(`${API}/services`);
      if (!r.ok) throw new Error();
      setServices(await r.json());
    } catch {
      setNotice("Backend connect aagala. Terminal-la npm run dev run pannunga.");
    }
  }
  useEffect(() => { loadServices(); }, []);
  const filtered = useMemo(() => services.filter(s =>
    (category === "All" || s.category === category) &&
    `${s.title} ${s.description} ${s.category}`.toLowerCase().includes(search.toLowerCase())
  ), [services, category, search]);
  const set = (key, value) => setForm(old => ({ ...old, [key]: value }));
  const total = chosen ? Number(chosen.price) * Math.max(1, Number(form.quantity) || 1) : 0;

  async function book(e) {
    e.preventDefault();
    setBusy(true);
    setNotice("");
    try {
      const r = await fetch(`${API}/bookings`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, quantity: Number(form.quantity), hours: Number(form.hours), serviceId: chosen._id })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message || "Booking failed.");
      setNotice(`${data.message} Status: ${data.booking.status}. Estimate: ₹${Number(data.booking.estimate).toLocaleString("en-IN")}`);
      setChosen(null);
      setForm(f => ({ ...f, customerName: "", phone: "", eventDate: "", location: "", notes: "", quantity: "1", hours: "1" }));
    } catch (e) { setNotice(e.message || "Booking failed. Check the backend."); }
    finally { setBusy(false); }
  }

  return <div className="page">
    <nav className="nav"><a className="logo" href="#"><span className="logo-symbol">Sx</span><span>Shaadi<span className="pink">X</span><small>EVENTS, MADE EASY</small></span></a><a className="nav-link" href="#services">Explore services ↗</a></nav>
    <header className="hero">
      <div className="hero-text"><span className="kicker">PLAN LESS. CELEBRATE MORE.</span><h1>Your event,<br/><i>beautifully</i> done.</h1><p>Find the right people for your big day. Book catering, cooks, serving staff, dance teams and all your event essentials in one place.</p><a className="cta" href="#services">Explore all services <b>→</b></a><div className="proof"><span>✦ 14+ service options</span><span>✦ One simple booking</span></div></div>
      <div className="hero-visual"><div className="ring ring1"></div><div className="ring ring2"></div><div className="hero-note"><span>✿</span><small>YOUR SPECIAL DAY</small><strong>Made of<br/>memories.</strong><hr/><small>WEDDINGS · PARTIES · EVENTS</small></div><span className="spark s1">✦</span><span className="spark s2">✧</span><span className="spark s3">♡</span></div>
    </header>

    <main id="services" className="services"><div className="section-top"><div><span className="kicker">YOUR EVENT CHECKLIST</span><h2>Find your people.</h2><p>Browse services and send a booking request.</p></div><span className="count">{filtered.length} available</span></div>
      <div className="search-wrap"><span>⌕</span><input aria-label="Search services" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search catering, cooks, dance, decoration…"/></div>
      <div className="filters">{categories.map(c => <button key={c} onClick={() => setCategory(c)} className={category === c ? "chip selected" : "chip"}>{c}</button>)}</div>
      <div className="grid">{filtered.map(s => <article className="service" key={s._id}><div className="service-art"><span className="emoji">{s.emoji || "✨"}</span><span className="tag">{s.category}</span></div><div className="service-body"><h3>{s.title}</h3><p>{s.description}</p><div className="service-foot"><div><strong>₹{Number(s.price).toLocaleString("en-IN")}</strong><small>{s.unit}</small></div><button onClick={() => {setChosen(s);setNotice("");}} className="book">Book <span>↗</span></button></div></div></article>)}</div>
      {filtered.length === 0 && <div className="empty">No matching services. Try a different search.</div>}
      {notice && <div className="notice" role="status">{notice}<button onClick={() => setNotice("")}>×</button></div>}
    </main>
    <section className="how"><span className="kicker">THREE EASY STEPS</span><h2>From idea to booked.</h2><div className="steps"><div><b>01</b><h3>Pick a service</h3><p>Find what your event needs.</p></div><div><b>02</b><h3>Tell us the details</h3><p>Date, location and team size.</p></div><div><b>03</b><h3>Send your request</h3><p>Get the booking process started.</p></div></div></section>
    <footer><a className="logo" href="#"><span className="logo-symbol">Sx</span><span>Shaadi<span className="pink">X</span><small>EVENTS, MADE EASY</small></span></a><small>Celebrate your way · © {new Date().getFullYear()} ShaadiX</small></footer>

    {chosen && <div className="overlay" onMouseDown={e => {if(e.target === e.currentTarget) setChosen(null);}}><form className="modal" onSubmit={book}><button className="close" type="button" onClick={() => setChosen(null)}>×</button><span className="kicker">BOOKING REQUEST</span><h2>{chosen.title}</h2><p className="muted">{chosen.description}</p><div className="form-grid">
      <label>Full name<input required maxLength="100" value={form.customerName} onChange={e => set("customerName",e.target.value)} placeholder="Your name"/></label>
      <label>Phone number<input required type="tel" pattern="[0-9+() -]{7,25}" value={form.phone} onChange={e => set("phone",e.target.value)} placeholder="Mobile number"/></label>
      <label>Event type<select value={form.eventType} onChange={e => set("eventType",e.target.value)}><option>Marriage</option><option>College function</option><option>Birthday</option><option>Engagement</option><option>Corporate event</option><option>Other</option></select></label>
      <label>Event date<input required type="date" min={new Date().toLocaleDateString("en-CA")} value={form.eventDate} onChange={e => set("eventDate",e.target.value)}/></label>
      <label className="wide">Event location<input required maxLength="250" value={form.location} onChange={e => set("location",e.target.value)} placeholder="Town / venue / address"/></label>
      <label>Quantity / guests<input required type="number" min="1" max="500" value={form.quantity} onChange={e => set("quantity",e.target.value)}/></label>
      <label>Hours<input required type="number" min="1" max="24" value={form.hours} onChange={e => set("hours",e.target.value)}/></label>
      <label className="wide">Notes (optional)<textarea maxLength="1000" rows="2" value={form.notes} onChange={e => set("notes",e.target.value)} placeholder="Menu, timing or special requests"/></label>
    </div><div className="total"><div><small>Estimated amount</small><strong>₹{total.toLocaleString("en-IN")}</strong><small>Estimate only; provider may quote a different final price.</small></div><button className="cta" disabled={busy}>{busy ? "Sending…" : "Send request →"}</button></div></form></div>}
  </div>;
}
