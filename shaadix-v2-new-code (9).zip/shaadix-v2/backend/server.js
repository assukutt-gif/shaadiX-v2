import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import Service from "./models/Service.js";
import Booking from "./models/Booking.js";

dotenv.config();
const app = express();
app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json({ limit: "30kb" }));

const starterServices = [
  ["Wedding Catering", "Catering", "Veg and non-veg menu options for events.", 250, "per guest", "🍛"],
  ["Traditional Cook / Chef", "Cooks & Chefs", "Professional cooks for your event kitchen.", 1800, "per shift", "👨‍🍳"],
  ["Catering Boys / Waiters", "Staff", "Food-serving team for buffet and dining.", 800, "per person / shift", "🧑‍🍽️"],
  ["Kitchen Helpers", "Staff", "Extra hands for food preparation and serving.", 700, "per person / shift", "🥣"],
  ["Dance Team", "Entertainment", "Dance performers for weddings and college functions.", 6000, "per booking", "💃"],
  ["DJ and Sound", "Entertainment", "Music, DJ and sound system.", 5000, "per booking", "🎧"],
  ["Stage Decoration", "Decoration", "Flower and theme-based stage decoration.", 12000, "per booking", "💐"],
  ["Photography", "Photography", "Event photography coverage.", 10000, "per booking", "📸"],
  ["Videography", "Photography", "Video coverage for special moments.", 9000, "per booking", "🎥"],
  ["Makeup Artist", "Beauty", "Bridal and event makeup services.", 5000, "per booking", "💄"],
  ["Marriage / Event Hall", "Venue", "Venue booking enquiry.", 25000, "per booking", "🏛️"],
  ["Cleaning Staff", "Staff", "Cleaning team before or after the event.", 700, "per person / shift", "🧹"],
  ["Mehndi Artist", "Beauty", "Mehndi designs for wedding celebrations.", 2500, "per booking", "🌿"],
  ["Flower Decoration", "Decoration", "Fresh flower decoration for the event.", 4500, "per booking", "🌸"]
].map(([title, category, description, price, unit, emoji]) => ({ title, category, description, price, unit, emoji }));

let demoServices = starterServices.map((s, i) => ({ ...s, _id: `demo-${i + 1}`, active: true }));
let demoBookings = [];

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, database: mongoose.connection.readyState === 1 ? "connected" : "demo mode" });
});

app.get("/api/services", async (req, res) => {
  try {
    const search = String(req.query.search || "").trim().slice(0, 80);
    const category = String(req.query.category || "").trim();
    if (mongoose.connection.readyState !== 1) {
      const list = demoServices.filter(s => s.active &&
        (!category || category === "All" || s.category === category) &&
        (!search || `${s.title} ${s.category} ${s.description}`.toLowerCase().includes(search.toLowerCase())));
      return res.json(list);
    }
    let query = { active: true };
    if (category && category !== "All") query.category = category;
    if (search) query.$or = [
      { title: { $regex: search, $options: "i" } },
      { category: { $regex: search, $options: "i" } },
      { description: { $regex: search, $options: "i" } }
    ];
    let services = await Service.find(query).sort({ category: 1, title: 1 });
    if (!services.length && !search && (!category || category === "All")) {
      await Service.insertMany(starterServices);
      services = await Service.find(query).sort({ category: 1, title: 1 });
    }
    res.json(services);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Could not load services." });
  }
});

app.post("/api/bookings", async (req, res) => {
  const b = req.body || {};
  const required = ["customerName", "phone", "eventType", "eventDate", "location", "serviceId"];
  if (!required.every(k => typeof b[k] === "string" && b[k].trim())) {
    return res.status(400).json({ message: "Please fill in all required fields." });
  }
  const quantity = Number(b.quantity);
  const hours = Number(b.hours);
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 500 || !Number.isInteger(hours) || hours < 1 || hours > 24) {
    return res.status(400).json({ message: "Quantity must be 1–500 and hours must be 1–24." });
  }
  const eventDate = new Date(`${b.eventDate}T00:00:00`);
  if (Number.isNaN(eventDate.getTime()) || eventDate < new Date(new Date().toDateString())) {
    return res.status(400).json({ message: "Choose today or a future event date." });
  }
  const service = mongoose.connection.readyState === 1
    ? await Service.findById(b.serviceId).catch(() => null)
    : demoServices.find(s => s._id === b.serviceId);
  if (!service || service.active === false) return res.status(404).json({ message: "Service not found. Refresh and choose again." });

  const data = {
    customerName: b.customerName.trim().slice(0, 100),
    phone: b.phone.trim().slice(0, 25),
    eventType: b.eventType,
    eventDate: b.eventDate,
    location: b.location.trim().slice(0, 250),
    serviceId: String(service._id),
    serviceTitle: service.title,
    quantity,
    hours,
    estimate: Number(service.price) * quantity,
    notes: String(b.notes || "").slice(0, 1000)
  };
  try {
    if (mongoose.connection.readyState === 1) {
      const booking = await Booking.create(data);
      return res.status(201).json({ message: "Booking request sent!", booking });
    }
    const booking = { ...data, _id: `demo-${Date.now()}`, status: "Pending", createdAt: new Date().toISOString() };
    demoBookings.unshift(booking);
    return res.status(201).json({ message: "Booking request sent in demo mode. Connect MongoDB to save permanently.", booking });
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Booking could not be saved." });
  }
});

app.get("/api/bookings", async (_req, res) => {
  try {
    const list = mongoose.connection.readyState === 1
      ? await Booking.find().sort({ createdAt: -1 }).limit(100)
      : demoBookings;
    res.json(list);
  } catch (e) {
    console.error(e);
    res.status(500).json({ message: "Could not load bookings." });
  }
});

const port = process.env.PORT || 5000;
try {
  if (process.env.MONGO_URI) {
    await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 2500 });
    console.log("MongoDB connected");
  } else {
    console.log("MONGO_URI missing; demo mode enabled");
  }
} catch {
  console.warn("MongoDB unavailable; using temporary demo data. Bookings will be lost when server restarts.");
}
app.listen(port, () => console.log(`ShaadiX backend: http://localhost:${port}`));
