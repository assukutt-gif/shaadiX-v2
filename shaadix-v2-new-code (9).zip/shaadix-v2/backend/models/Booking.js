import mongoose from "mongoose";

const schema = new mongoose.Schema({
  customerName: { type: String, required: true, trim: true, maxlength: 100 },
  phone: { type: String, required: true, trim: true, maxlength: 25 },
  eventType: { type: String, required: true },
  eventDate: { type: String, required: true },
  location: { type: String, required: true, trim: true, maxlength: 250 },
  serviceId: { type: String, required: true },
  serviceTitle: { type: String, required: true },
  quantity: { type: Number, required: true, min: 1, max: 500 },
  hours: { type: Number, required: true, min: 1, max: 24 },
  estimate: { type: Number, required: true, min: 0 },
  notes: { type: String, default: "", maxlength: 1000 },
  status: { type: String, enum: ["Pending", "Accepted", "Completed", "Cancelled"], default: "Pending" }
}, { timestamps: true });

export default mongoose.model("Booking", schema);
