import mongoose from "mongoose";

const schema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  category: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  price: { type: Number, required: true, min: 0 },
  unit: { type: String, default: "per booking" },
  emoji: { type: String, default: "✨" },
  active: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model("Service", schema);
