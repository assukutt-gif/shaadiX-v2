# ShaadiX V2

New starter code for an all-event booking marketplace.

## Includes
- React responsive frontend
- Express backend REST API
- MongoDB models for services and bookings
- Search and category filters
- Booking form with event type, date, location, contact, quantity and hours
- Services for catering, cooks/chefs, catering boys/waiters, dance, DJ, decoration, photography, makeup, halls, cleaning and more

## Run
Install Node.js LTS and MongoDB (local or Atlas).
1. Open this folder in VS Code.
2. Run `npm install`
3. Run `npm run install:all`
4. Copy `backend/.env.example` to `backend/.env` and set `MONGO_URI`.
5. Run `npm run dev`
6. Open http://localhost:5173

The API runs at http://localhost:5000/api.
If MongoDB is not connected, the demo still shows services, but bookings are not saved persistently.
This is a starter/demo. Add real authentication, admin permissions, provider verification, payment integration, rate limits and production security before launch.
